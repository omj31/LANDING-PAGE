
// Scroll to Top button functionality
const scrollBtn = document.getElementById("scrollBtn");
window.onscroll = function () {
  scrollBtn.style.display = (document.documentElement.scrollTop > 300) ? "block" : "none";
};

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// Modal Logic
const modal = document.getElementById('serviceModal');
const modalTitle = document.getElementById('modalTitle');
const modalDescription = document.getElementById('modalDescription');
const modalIcon = document.getElementById('modalIcon');
const modalClose = document.getElementById('modalClose');

document.querySelectorAll('.service-cards .card').forEach(card => {
  card.addEventListener('click', () => {
    modalTitle.textContent = card.getAttribute('data-title');
    modalDescription.textContent = card.getAttribute('data-description');
    modalIcon.textContent = card.getAttribute('data-icon');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  });
});

modalClose.addEventListener('click', () => {
  modal.style.display = 'none';
  document.body.style.overflow = '';
});

window.addEventListener('click', e => {
  if (e.target === modal) {
    modal.style.display = 'none';
    document.body.style.overflow = '';
  }
});
